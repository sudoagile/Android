package com.example.netflix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NetflixApplication {

    public static void main(String[] args) {

        SpringApplication.run(NetflixApplication.class, args);
        Pelicula[] peliculas = new Pelicula[5];
        Serie[] series = new Serie[5];

        // Crear objetos de películas
        peliculas[0] = new Pelicula("Inception", "Sci-Fi", "Christopher Nolan", "2010", 148);
        peliculas[1] = new Pelicula("Titanic", "Romance", "James Cameron", "1997", 195);
        peliculas[2] = new Pelicula("Avatar", "Sci-Fi", "James Cameron", "2009", 162);
        peliculas[3] = new Pelicula("The Godfather", "Crime", "Francis Ford Coppola", "1972", 175);
        peliculas[4] = new Pelicula("The Dark Knight", "Action", "Christopher Nolan", "2008", 152);

        // Crear objetos de series
        series[0] = new Serie("Breaking Bad", 5, "Crime", "Vince Gilligan", 3000);
        series[1] = new Serie("Stranger Things", 4, "Sci-Fi", "The Duffer Brothers", 2000);
        series[2] = new Serie("Game of Thrones", 8, "Fantasy", "George R. R. Martin", 5000);
        series[3] = new Serie("The Office", 9, "Comedy", "Greg Daniels", 2200);
        series[4] = new Serie("Friends", 10, "Comedy", "David Crane", 3000);

        // Marcar como visto algunas películas y series
        peliculas[0].marcarVisto();
        peliculas[3].marcarVisto();
        series[2].marcarVisto();
        series[4].marcarVisto();

        // Mostrar las películas y series vistas
        System.out.println("Películas vistas:");
        for (Pelicula pelicula : peliculas) {
            if (pelicula.esVisto()) {
                System.out.println(pelicula);
            }
        }

        System.out.println("\nSeries vistas:");
        for (Serie serie : series) {
            if (serie.esVisto()) {
                System.out.println(serie);
            }
        }

        // Encontrar la serie con más temporadas y la película más reciente
        Serie serieConMasTemporadas = series[0];
        Pelicula peliculaMasReciente = peliculas[0];

        for (Serie serie : series) {
            if (serie.getNroTemporadas() > serieConMasTemporadas.getNroTemporadas()) {
                serieConMasTemporadas = serie;
            }
        }

        for (Pelicula pelicula : peliculas) {
            if (Integer.parseInt(pelicula.getAnio()) > Integer.parseInt(peliculaMasReciente.getAnio())) {
                peliculaMasReciente = pelicula;
            }
        }

        System.out.println("\nSerie con más temporadas:");
        System.out.println(serieConMasTemporadas);

        System.out.println("\nPelícula más reciente:");
        System.out.println(peliculaMasReciente);
    }


}
