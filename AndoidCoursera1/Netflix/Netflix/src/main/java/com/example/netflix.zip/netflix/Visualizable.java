package com.example.netflix;

public interface Visualizable {
    void marcarVisto();
    boolean esVisto();
    int tiempoVisto(); // Tiempo total visualizado
}
