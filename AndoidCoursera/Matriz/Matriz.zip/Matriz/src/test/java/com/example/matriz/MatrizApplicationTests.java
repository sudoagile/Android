package com.example.matriz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatrizApplicationTests {

    @Test
    void contextLoads() {
    }

}
